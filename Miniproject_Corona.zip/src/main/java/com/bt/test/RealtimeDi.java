package com.bt.test;

import java.util.Scanner;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;

import com.bt.controller.MainController;
import com.bt.vo.PatientVo;

public class RealtimeDi 
{
    public static void main( String[] args )
    {
    	Scanner sc=new Scanner(System.in);
		System.out.println("enter patient name::");
		String name=sc.next();
		System.out.println("enter patient addrs::");
		String addrs=sc.next();
		System.out.println("enter no hospitalized::");
		String phos=sc.next();
		System.out.println("enter bill::");
		String bill=sc.next();
		System.out.println("enter  discount)::");
		String disc=sc.next();
		
		PatientVo vo=new PatientVo();
		vo.setPName(name);
		vo.setPAddr(addrs); 
		vo.setNoOfHosp(phos);
		vo.setBillPDay(bill) ;
		vo.setDiscount(disc);
		//create IOC container
		 DefaultListableBeanFactory factory=new DefaultListableBeanFactory();
		 XmlBeanDefinitionReader reader=new XmlBeanDefinitionReader(factory);
		 reader.loadBeanDefinitions("com/bt/cfgs/applicationContext.xml");
		 //get Controller class obj 
		 MainController controller=factory.getBean("controller",MainController.class);
		 //invoke the methods
		 try {
			 String result=controller.processPatient(vo);
			 System.out.println(result);
		 }
		 catch(Exception e) {
			 //e.printStackTrace();
			 System.out.println("Internal Problem --Try Again:::"+e.getMessage());
		 }
    }
}
