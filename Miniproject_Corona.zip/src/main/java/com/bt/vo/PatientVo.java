package com.bt.vo;

public class PatientVo {
	
	private String PName;
	private String PAddr;
	private String NoOfHosp;
	private String BillPDay;
	private String Discount;
	
	
  public String getPName() {
		return PName;
	}


	public void setPName(String pName) {
		PName = pName;
	}


	public String getPAddr() {
		return PAddr;
	}


	public void setPAddr(String pAddr) {
		PAddr = pAddr;
	}


	public String getNoOfHosp() {
		return NoOfHosp;
	}


	public void setNoOfHosp(String noOfHosp) {
		NoOfHosp = noOfHosp;
	}


	public String getBillPDay() {
		return BillPDay;
	}


	public void setBillPDay(String billPDay) {
		BillPDay = billPDay;
	}


	public String getDiscount() {
		return Discount;
	}


	public void setDiscount(String discount) {
		Discount = discount;
	}


public String toString() {	
	  
	  return "PatientVO [patientName=" + PName + ",patientAddrs=" + PAddr+ ", NoofDaysHospitalized=" + NoOfHosp + ", bill=" + BillPDay
				+ ", Discount=" + Discount+ "]";
 
  }

}
