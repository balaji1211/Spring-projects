package com.bt.dao;

import com.bt.bo.PatientBo;

public interface IpatientDao {
	
	    public int insert(	PatientBo bo) throws Exception;

}
