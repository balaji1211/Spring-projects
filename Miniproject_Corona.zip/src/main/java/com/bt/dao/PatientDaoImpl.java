package com.bt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.bt.bo.PatientBo;


public class PatientDaoImpl implements IpatientDao {
	private static final String  REALTIMEDI_CORONA_INSERT_QUERY="INSERT INTO REALTIMEDI_CORONA VALUES(?,?,?,?,?,?,?)";
	private DataSource ds;
	
	public PatientDaoImpl(DataSource ds ) {
		System.out.println("CORONADAOImpl:: 1 -param constructor");
		  this.ds= ds;
	}

	
	@Override
     public int insert(PatientBo bo)throws Exception {
		Connection con=null;
		PreparedStatement ps=null;
		int count=0;
		
	     try {
	    	      con = ds.getConnection();
	    	      ps = con.prepareStatement(REALTIMEDI_CORONA_INSERT_QUERY);
	    	       
	    	    ps.setString(1, bo.getPName());
	  			ps.setString(2, bo.getPAddr());
	  			ps.setInt(3,bo.getNoOfHosp());
	  			ps.setFloat(4,bo.getBillPDay());
	  			ps.setFloat(5,bo.getTotalBAmt());
	  			ps.setFloat(6,bo.getDiscount());
	  			ps.setFloat(7, bo.getNetBAmt());
	  			//execute the Query
	  			count=ps.executeUpdate();
 
	     }
	    
	     catch(SQLException se) {
				se.printStackTrace();
				throw se;  // Exception rethrowing
			}
	     
	     catch(Exception e) {
	    	 e.printStackTrace();
	    	 throw e;
	     }
	     
	     finally {
				//close jdbc objs
				try {
					if(ps!=null)
						ps.close();
				}
				catch(SQLException se) {
					se.printStackTrace();
					throw se;
				}
				try {
					if(con!=null)
						con.close();
				}
				catch(SQLException se) {
					se.printStackTrace();
					throw se;
				}
			}//finally
		
		
		return count; 
	}



}
