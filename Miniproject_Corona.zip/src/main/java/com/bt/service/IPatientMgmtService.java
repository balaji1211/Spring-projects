package com.bt.service;

import com.bt.dto.PatientDTO;

public interface IPatientMgmtService {
	
	public String calculateBillAmount(PatientDTO dto) throws Exception;

}
