package com.bt.service;

import com.bt.bo.PatientBo;
import com.bt.dao.IpatientDao;
import com.bt.dto.PatientDTO;

public class PatientMgmtServiceImpl implements IPatientMgmtService  {
	
	private IpatientDao dao;
	
   public 	PatientMgmtServiceImpl(IpatientDao dao)  {
	   System.out.println("PatientMgmtServiceImpl.PatientMgmtServiceImpl()");
	   this.dao=dao;
	   
   }

	@Override
	public String calculateBillAmount(PatientDTO dto) throws Exception {
		
	float amt =	dto.getNoOfHosp()*dto.getBillPDay();
	float discount=0;
	if (amt>100000) {
		discount = 20/amt*100;
	}
	if (amt>200000) {
		discount = 30/amt*100;
	}
	PatientBo bo = new PatientBo();
	bo.setPName(dto.getPName());
	bo.setPAddr(dto.getPAddr());
	bo.setBillPDay(dto.getBillPDay());
	bo.setNoOfHosp(dto.getNoOfHosp());
	bo.setTotalBAmt(amt);
	bo.setDiscount(discount);
	//use DAO
	int count=dao.insert(bo);
	  // terinary operator   <condition>?<sucess>:<failure>
	return  count==1?"patient registration successfully---> TotalAmount:"+amt+"discount"+discount:"Patient registration failed";   
		
	}

}
