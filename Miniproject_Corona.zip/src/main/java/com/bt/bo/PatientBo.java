package com.bt.bo;

public class PatientBo {

	private String PName;
	private String PAddr;
	private int NoOfHosp;
	private float BillPDay;
	private float Discount;
	private float TotalBAmt;
	private float NetBAmt;
	
	public float getTotalBAmt() {
		return TotalBAmt;
	}
	public void setTotalBAmt(float totalBAmt) {
		TotalBAmt = totalBAmt;
	}
	public float getNetBAmt() {
		return NetBAmt;
	}
	public void setNetBAmt(float netBAmt) {
		NetBAmt = netBAmt;
	}
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public String getPAddr() {
		return PAddr;
	}
	public void setPAddr(String pAddr) {
		PAddr = pAddr;
	}
	public int getNoOfHosp() {
		return NoOfHosp;
	}
	public void setNoOfHosp(int noOfHosp) {
		NoOfHosp = noOfHosp;
	}
	public float getBillPDay() {
		return BillPDay;
	}
	public void setBillPDay(float billPDay) {
		BillPDay = billPDay;
	}
	public float getDiscount() {
		return Discount;
	}
	public void setDiscount(float discount) {
		Discount = discount;
	}
	
	public String toString() {	
		  
		  return "PatientBO[patientName=" + PName + ",patientAddrs=" + PAddr+ ", NoofDaysHospitalized=" + NoOfHosp + ", bill=" + BillPDay
					+ ", Discount=" + Discount+ ",Total balance="+TotalBAmt+"]";
	 
	  }
	
		
}
