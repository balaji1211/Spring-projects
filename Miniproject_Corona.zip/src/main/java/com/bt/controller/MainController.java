package com.bt.controller;

import com.bt.dto.PatientDTO;
import com.bt.service.IPatientMgmtService;
import com.bt.vo.PatientVo;

public class MainController {
	
	private IPatientMgmtService service;
	
	public MainController(IPatientMgmtService service) {
		System.out.println("MainController: 1-param constructor");
		  this.service=service;
	}
	
	public  String  processPatient(PatientVo vo)throws Exception {
		//convert  VO class obj data to DTO class object data
		PatientDTO dto=new PatientDTO();
		dto.setPName(vo.getPName());
		dto.setPAddr(vo.getPAddr());
		dto.setNoOfHosp(Integer.parseInt(vo.getNoOfHosp()));
		dto.setBillPDay(Float.parseFloat(vo.getBillPDay()));
		dto.setDiscount(Float.parseFloat(vo.getDiscount()));
		
		//use service
		String result=service.calculateBillAmount(dto);
		return result;
	}

}
