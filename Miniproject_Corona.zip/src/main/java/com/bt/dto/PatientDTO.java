package com.bt.dto;

public class PatientDTO {
	
	private String PName;
	private String PAddr;
	private int NoOfHosp;
	private float BillPDay;
	private float Discount;
	public String getPName() {
		return PName;
	}
	public void setPName(String pName) {
		PName = pName;
	}
	public String getPAddr() {
		return PAddr;
	}
	public void setPAddr(String pAddr) {
		PAddr = pAddr;
	}
	public int getNoOfHosp() {
		return NoOfHosp;
	}
	public void setNoOfHosp(int noOfHosp) {
		NoOfHosp = noOfHosp;
	}
	public float getBillPDay() {
		return BillPDay;
	}
	public void setBillPDay(float billPDay) {
		BillPDay = billPDay;
	}
	public float getDiscount() {
		return Discount;
	}
	public void setDiscount(float discount) {
		Discount = discount;
	}
	
	public String toString() {	
		  
		  return "PatientDTO [patientName=" + PName + ",patientAddrs=" + PAddr+ ", NoofDaysHospitalized=" + NoOfHosp + ", bill=" + BillPDay
					+ ", Discount=" + Discount+ "]";
	 
	  }
		

}
